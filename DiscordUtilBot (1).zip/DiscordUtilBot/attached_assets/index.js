// This file is deprecated and should not be used.
// Please refer to ../index.js for the current implementation.
console.log("Warning: Deprecated file being loaded");